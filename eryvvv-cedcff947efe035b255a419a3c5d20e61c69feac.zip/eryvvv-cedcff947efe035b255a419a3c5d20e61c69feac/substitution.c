#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    // Check if program has command-line argument
    if (argc != 2)
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }
    else 
    {
        for (int i = 0, n = strlen(argv[1]); i < n; i++)
        {
            // Check if its all letters
            if (isdigit(argv[1][i]))
            {
                printf("Usage: ./substitution key\n");
                return 1;
            }
            else if (ispunct(argv[1][i]))
            {
                printf("Usage: ./substitution key\n");
                return 1;
            }
            else if (isspace(argv[1][i]))
            {
                printf("Usage: ./substitution key\n");
                return 1;
            }
        
            // Check if its 26 letters
            else if (n != 26)
            {
                printf("Usage: ./substitution key\n");
                return 1;
            }
        
            // Check if there are no duplicate letters
            for (int j = 0; j < strlen(argv[1]); j++)
            {
                for (int k = j + 1; k < strlen(argv[1]); k++)
                {
                    if (argv[1][j] == argv[1][k])
                    {
                        printf("Usage: ./substitution key\n");
                        return 1;
                    }
                }
            }
        }    
    }
    
    // If Key okay, ask for plain text
    string plain = get_string("plaintext: ");
    string key = argv[1];
   
//Convert plaintext to ciphertext
    printf("ciphertext: ");
    for (int l = 0; l < strlen(plain); l++) // loop for plaintext
    {
        for (int m = 0; m < 26; m++) // loop for key
        {
            if (islower(plain[l])) 
            {               
                if (plain[l] == 'a' + m) 
                {
                    printf("%c", tolower(key[m]));
                }

            }
            else if (isupper(plain[l])) 
            {
                if (plain[l] == 'A' + m)
                {
                    printf("%c", toupper(key[m]));
                }
            }
        }
        if (!isalpha(plain[l])) // If not a letter, retain
        {
            printf("%c", plain[l]);
        }
    }
    printf("\n");
}
